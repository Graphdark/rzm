// /****************************************************************************
//
// Utility base class for widgets that represents options for actions
//
// Copyright (C) 2025 LibreCAD.org
// Copyright (C) 2025 sand1024
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
// **********************************************************************
//

#include "stdafx.h"

#include <xlocale>
#include <codecvt>


#include "lc_makercamsvg.h"

//#include "lc_splinepoints.h"
#include "lc_xmlwriterinterface.h"


#include "dbxHeaders.h"

#include "stringConv.h"



//#include "rs_arc.h"
//#include "rs_block.h"
//#include "rs_circle.h"
//#include "rs_debug.h"
//#include "rs_ellipse.h"
//#include "rs_graphic.h"
//#include "rs_image.h"
//#include "rs_insert.h"
//#include "rs_layer.h"
//#include "rs_line.h"

#include "rs_math.h"
//#include "rs_point.h"
//#include "rs_polyline.h"
//#include "rs_spline.h"
//#include "rs_units.h"
//#include "rs_utility.h"

namespace {
const std::string NAMESPACE_URI_SVG = "http://www.w3.org/2000/svg";
const std::string NAMESPACE_URI_LC = "https://librecad.org";
const std::string NAMESPACE_URI_XLINK = "http://www.w3.org/1999/xlink";
}

LC_MakerCamSVG::LC_MakerCamSVG(std::unique_ptr<LC_XMLWriterInterface> xmlWriter,
                               bool writeInvisibleLayers,
                               bool writeConstructionLayers,
                               bool writeBlocksInline,
                               bool convertEllipsesToBeziers,
                               bool exportImages,
                               bool convertLineTypes,
                               double defaultElementWidth,
                               double defaultDashLinePatternLength):
  xmlWriter(std::move(xmlWriter))
  ,writeInvisibleLayers(writeInvisibleLayers)
  ,writeConstructionLayers(writeConstructionLayers)
  ,writeBlocksInline(writeBlocksInline)
  ,convertEllipsesToBeziers(convertEllipsesToBeziers)
  ,exportImages(exportImages)
  ,convertLineTypes(convertLineTypes)
  ,defaultElementWidth(defaultElementWidth)
  ,defaultDashLinePatternLength(defaultDashLinePatternLength)

  ,offset(0.,0.)
{
    //RS_DEBUG->print("RS_MakerCamSVG::RS_MakerCamSVG()");
}

bool LC_MakerCamSVG::generate(RS_Graphic* graphic) {

    write(graphic);

    return true;
}

std::string LC_MakerCamSVG::resultAsString() {

   return xmlWriter->documentAsString();
}

void LC_MakerCamSVG::write(RS_Graphic* graphic) {

    //RS_DEBUG->print("RS_MakerCamSVG::write: Writing root node ...");

    //graphic->calculateBorders();

  min = graphic->extmin().asPoint2d();   //getMin();
  max = graphic->extmax().asPoint2d();  // getMax();

  RS2::Unit raw_unit = (RS2::Unit)graphic->unitmode();  //graphic->getUnit();
    lengthFactor=1.;
    switch (raw_unit) {
        case RS2::Centimeter:
            unit = "cm";
            break;
        case RS2::Inch:
            unit = "in";
            break;

        default:
            //lengthFactor=RS_Units::convert(1., raw_unit, RS2::Millimeter);
          lengthFactor = 1.0;
            // falling through will make default will use mm and convert length to mm
            // fall-through
        case RS2::Millimeter:
            unit = "mm";
            break;
    }

    xmlWriter->createRootElement("svg", NAMESPACE_URI_SVG);

    xmlWriter->addNamespaceDeclaration("lc", NAMESPACE_URI_LC);
    xmlWriter->addNamespaceDeclaration("xlink", NAMESPACE_URI_XLINK);

    xmlWriter->addAttribute("width", lengthXml(max.x - min.x) + unit);
    xmlWriter->addAttribute("height", lengthXml(max.y - min.y) + unit);
    xmlWriter->addAttribute("viewBox", "0 0 "+ lengthXml(max.x - min.x) + " " + lengthXml(max.y - min.y));

    writeBlocks(graphic);
    writeLayers(graphic);
}

void LC_MakerCamSVG::writeBlocks(RS_Document* document) {

    if (!writeBlocksInline) {

        //RS_DEBUG->print("RS_MakerCamSVG::writeBlocks: Writing blocks ...");

        //RS_BlockList* blocklist = document->getBlockList();
      AcDbBlockTable* pBlkTable;
      document->getBlockTable(pBlkTable, AcDb::kForRead);

      AcDbBlockTableIterator* iter;
      pBlkTable->newIterator(iter);

        //if (blocklist->count() > 0) 
      if (!iter->done())
        {
            xmlWriter->addElement("defs", NAMESPACE_URI_SVG);

            //for (int i = 0; i < blocklist->count(); i++) 
            for (iter->start(); !iter->done(); iter->step())
            {
                //writeBlock(blocklist->at(i));
              AcDbBlockTableRecord* r;
              iter->getRecord(r, AcDb::kForRead);
              writeBlock(r);
            }

            xmlWriter->closeElement();
        }

    }
}

AcDbSymbolTable* openSymbolTable(AcRxClass* symTblClass,  AcDb::OpenMode mode, AcDbDatabase* db)
{
  ASSERT(symTblClass != NULL);
  ASSERT(db != NULL);

  AcDbSymbolTable* symTbl = NULL;
  Acad::ErrorStatus es;

  if (symTblClass == AcDbBlockTableRecord::desc()) {
    AcDbBlockTable* blkTbl;
    es = db->getBlockTable(blkTbl, mode);
    symTbl = blkTbl;
  }
  else if (symTblClass == AcDbDimStyleTableRecord::desc()) {
    AcDbDimStyleTable* dimTbl;
    es = db->getDimStyleTable(dimTbl, mode);
    symTbl = dimTbl;
  }
  else if (symTblClass == AcDbLayerTableRecord::desc()) {
    AcDbLayerTable* layerTbl;
    es = db->getLayerTable(layerTbl, mode);
    symTbl = layerTbl;
  }
  else if (symTblClass == AcDbLinetypeTableRecord::desc()) {
    AcDbLinetypeTable* ltypeTbl;
    es = db->getLinetypeTable(ltypeTbl, mode);
    symTbl = ltypeTbl;
  }
  else if (symTblClass == AcDbTextStyleTableRecord::desc()) {
    AcDbTextStyleTable* textTbl;
    es = db->getTextStyleTable(textTbl, mode);
    symTbl = textTbl;
  }
  else if (symTblClass == AcDbRegAppTableRecord::desc()) {
    AcDbRegAppTable* appTbl;
    es = db->getRegAppTable(appTbl, mode);
    symTbl = appTbl;
  }
  else if (symTblClass == AcDbUCSTableRecord::desc()) {
    AcDbUCSTable* ucsTbl;
    es = db->getUCSTable(ucsTbl, mode);
    symTbl = ucsTbl;
  }
  else if (symTblClass == AcDbViewTableRecord::desc()) {
    AcDbViewTable* viewTbl;
    es = db->getViewTable(viewTbl, mode);
    symTbl = viewTbl;
  }
  else if (symTblClass == AcDbViewportTableRecord::desc()) {
    AcDbViewportTable* vportTbl;
    es = db->getViewportTable(vportTbl, mode);
    symTbl = vportTbl;
  }
  else
    es = Acad::eInvalidInput;    // passed in a class type that is illegal

  ASSERT(es == Acad::eOk);    // should never fail!
  if (es != Acad::eOk) {
    //ArxDbgUtils::rxErrorMsg(es);
    return NULL;
  }
  else
    return symTbl;
}

Acad::ErrorStatus collectSymbolIds(AcRxClass* symTblClass, AcDbObjectIdArray& objIds, AcDbDatabase* db)
{
  ASSERT(symTblClass != NULL);
  ASSERT(db != NULL);

  Acad::ErrorStatus retCode = Acad::eInvalidInput;

  AcDbSymbolTable* symTbl = openSymbolTable(symTblClass, AcDb::kForRead, db);
  if (symTbl != NULL) {
    // get an iterator over this symbol Table
    AcDbSymbolTableIterator* tblIter;
    if (symTbl->newIterator(tblIter) == Acad::eOk) {
      // walk table and just collect all the objIds
      // of the entries
      Acad::ErrorStatus es;
      AcDbObjectId tblRecId;
      for (; !tblIter->done(); tblIter->step()) {
        es = tblIter->getRecordId(tblRecId);
        if (es == Acad::eOk)
          objIds.append(tblRecId);
      }
#ifndef _NCAD_BUILD_NODELETE
      delete tblIter;
#endif
      retCode = Acad::eOk;
    }
    symTbl->close();
  }
  return retCode;
}



void LC_MakerCamSVG::writeBlock(RS_Block* block) {

    //RS_DEBUG->print("RS_MakerCamSVG::writeBlock: Writing block with name '%s'", qPrintable(block->getName()));

    xmlWriter->addElement("g", NAMESPACE_URI_SVG);

    xmlWriter->addAttribute("id", std::to_string(block->objectId().asOldId()));
    //xmlWriter->addAttribute("blockname", qPrintable(block->getName()), NAMESPACE_URI_LC);

    const NCHAR* name; block->getName(name);

    xmlWriter->addAttribute("blockname", toUtf8(name), NAMESPACE_URI_LC);

    writeLayers(block->database());

    xmlWriter->closeElement();
}

void LC_MakerCamSVG::writeLayers(RS_Document* document) {

    //RS_DEBUG->print("RS_MakerCamSVG::writeLayers: Writing layers ...");

    //RS_LayerList* layerlist = document->getLayerList();
    AcDbObjectIdArray objIds;
    collectSymbolIds(AcDbLayerTableRecord::desc(), objIds, document);

    //for (unsigned int i = 0; i < layerlist->count(); i++) 
    for (int i = 0; i < objIds.length(); i++)
    {
        //writeLayer(document, layerlist->at(i));
      AcDbLayerTableRecord* layer;
      if (acdbOpenObject(layer, objIds[i], AcDb::kForRead) == Acad::eOk)
      {
        writeLayer(document, layer);
        layer->close();
      }
    }
}

void LC_MakerCamSVG::writeLayer(RS_Document* document, RS_Layer* layer) {

    if (writeInvisibleLayers || !layer->isFrozen()) {

        //if (writeConstructionLayers || !layer->isConstruction()) {
        if (writeConstructionLayers || !layer->isOff()) {

            //RS_DEBUG->print("RS_MakerCamSVG::writeLayer: Writing layer with name '%s'", qPrintable(layer->getName()));

            xmlWriter->addElement("g", NAMESPACE_URI_SVG);

            //xmlWriter->addAttribute("layername", qPrintable(layer->getName()), NAMESPACE_URI_LC);

            xmlWriter->addAttribute("is_locked", (layer->isLocked() ? "true" : "false"), NAMESPACE_URI_LC);
            //xmlWriter->addAttribute("is_construction", (layer->isConstruction() ? "true" : "false"), NAMESPACE_URI_LC);
            xmlWriter->addAttribute("is_off", (layer->isOff() ? "true" : "false"), NAMESPACE_URI_LC);

            if (layer->isFrozen())
            {
                xmlWriter->addAttribute("style", "display: none;");
            }

            xmlWriter->addAttribute("fill", "none");
            xmlWriter->addAttribute("stroke", "black");
            //xmlWriter->addAttribute("stroke-width", QString::number(defaultElementWidth).toStdString());
            xmlWriter->addAttribute("stroke-width", std::to_string(defaultElementWidth));

            writeEntities(document, layer);

            xmlWriter->closeElement();
        }
        else {

            //RS_DEBUG->print("RS_MakerCamSVG::writeLayer: Omitting construction layer with name '%s'", qPrintable(layer->getName()));
        }
    }
    else {

        //RS_DEBUG->print("RS_MakerCamSVG::writeLayer: Omitting invisible layer with name '%s'", qPrintable(layer->getName()));
    }
}



void LC_MakerCamSVG::writeEntities(RS_Document* document, RS_Layer* layer) {

    //RS_DEBUG->print("RS_MakerCamSVG::writeEntities: Writing entities from layer ...");

  //for (auto e: *document)
  //if (e->getLayer() == layer)
  //    if (!(e->getFlag(RS2::FlagUndone)))
  //        writeEntity(e);
  AcDbBlockTable* pBlockTable;
  acdbOpenObject(pBlockTable, document->blockTableId(), AcDb::kForRead);
  AcDbBlockTableRecord* pBlockTableRecord;
  pBlockTable->getAt(ACDB_MODEL_SPACE, pBlockTableRecord, AcDb::kForRead);
  AcDbBlockTableRecordIterator* pBlockIterator = NULL;
  pBlockTableRecord->newIterator(pBlockIterator);
  for(;pBlockIterator->done(); pBlockIterator->step())
  {
    AcDbObjectId objId;
    pBlockIterator->getEntityId(objId);
    AcDbEntity* e;
    if (acdbOpenAcDbEntity(e, objId, AcDb::kForRead))
    {
      writeEntity(e);
      e->close();
    }
  }
  pBlockTableRecord->close();
  pBlockTable->close();
}

void LC_MakerCamSVG::writeEntity(RS_Entity* entity) {

    //RS_DEBUG->print("RS_MakerCamSVG::writeEntity: Found entity ...");

    if (entity->isKindOf(RS_Insert::desc()))
       writeInsert((RS_Insert*)entity);
    else
      if (entity->isKindOf(RS_Point::desc()))
      {
        if (m_exportPoints) {
          writePoint((RS_Point*)entity);
        }
      }
      else
        if (entity->isKindOf(RS_Line::desc()))
          writeLine((RS_Line*)entity);
        else
          if (entity->isKindOf(RS_Polyline::desc()))
            writePolyline((RS_Polyline*)entity);
          else
            if (entity->isKindOf(RS_Circle::desc()))
              writeCircle((RS_Circle*)entity);
            else
              if (entity->isKindOf(RS_Arc::desc()))
                writeArc((RS_Arc*)entity);
              else
                if (entity->isKindOf(RS_Ellipse::desc()))
                  writeEllipse((RS_Ellipse*)entity);
                else
                  if (entity->isKindOf(RS_Spline::desc()))
                    writeSpline((RS_Spline*)entity);
                  else
                    if (entity->isKindOf(RS_Image::desc()))
                      writeImage((RS_Image*)entity);
                      
        //case RS2::EntitySplinePoints:
        //    writeSplinepoints((LC_SplinePoints*)entity);
}

void LC_MakerCamSVG::writeInsert(RS_Insert* insert) {

    //RS_Block* block = insert->getBlockForInsert();
  RS_Block* block;
  acdbOpenObject(block, insert->blockTableRecord(), AcDb::kForRead);

    //RS_Vector insertionpoint = insert->getInsertionPoint();
  RS_Vector insertionpoint = insert->position().asPoint2d();

    // The conversion from drawing space to the svg space (column major) transform matrix(M):
    // 1  0  0
    // 0 -1  max.y
    // 0  0  1
    // Or: MV = RV + T, with R the rotation part, T the translation part, T=(0; max.y)
    // For insertions the transform should be M(V + I), with I as the insertion point offset
    // M(V+I) = R(V+I) + T = M(V) + RI
    // Therefore, insertion point offset means RI in SVG offset
    // (x, y) -> (x, -y)

    if (writeBlocksInline) {

        //RS_DEBUG->print("RS_MakerCamSVG::writeInsert: Writing insert inline ...");

        offset.set(insertionpoint.x, - insertionpoint.y);

        xmlWriter->addElement("g", NAMESPACE_URI_SVG);

        const NCHAR* name;
        block->getName(name);
        xmlWriter->addAttribute("blockname", toUtf8(name), NAMESPACE_URI_LC);

        writeLayers(block->database());

        xmlWriter->closeElement();

        offset.set(0, 0);
    }
    else {

        //RS_DEBUG->print("RS_MakerCamSVG::writeInsert: Writing insert as reference to block ...");

        xmlWriter->addElement("use", NAMESPACE_URI_SVG);

        xmlWriter->addAttribute("x", lengthXml(insertionpoint.x));
        xmlWriter->addAttribute("y", lengthXml(- insertionpoint.y));
        xmlWriter->addAttribute("href", "#" + std::to_string(block->objectId().asOldId()), NAMESPACE_URI_XLINK);

        xmlWriter->closeElement();
    }
}

void LC_MakerCamSVG::writePoint(RS_Point* point) {

    //RS_DEBUG->print("RS_MakerCamSVG::writePoint: Writing point ...");

    // NOTE: There is no "point" element in SVG, therefore creating a circle
    //       with minimal radius.

    RS_Vector center = convertToSvg(point->position().asPoint2d());

    xmlWriter->addElement("circle", NAMESPACE_URI_SVG);

    xmlWriter->addAttribute("cx", lengthXml(center.x));
    xmlWriter->addAttribute("cy", lengthXml(center.y));
    xmlWriter->addAttribute("r", lengthXml(0.1));

    xmlWriter->closeElement();
}

void LC_MakerCamSVG::writeLine(RS_Line* line) {

    //RS_DEBUG->print("RS_MakerCamSVG::writeLine: Writing line ...");

    RS_Vector startpoint = convertToSvg(line->startPoint().asPoint2d());
    RS_Vector endpoint = convertToSvg(line->endPoint().asPoint2d());

    //RS_Pen pen = line->getPen();
    //RS2::LineType lineType = pen.getLineType();

    //if ((RS2::SolidLine != lineType) & convertLineTypes ) 
    //{
    //    RS_DEBUG->print("RS_MakerCamSVG::writeLine: write baked line as path");

    //    std::string path;
    //    path += svgPathAnyLineType(startpoint, endpoint, pen.getLineType());

    //    xmlWriter->addElement("path", NAMESPACE_URI_SVG);
    //    xmlWriter->addAttribute("id", QString::number(line->getId()).toStdString());
    //    if (RS2::Width00 != pen.getWidth()){
    //        xmlWriter->addAttribute("stroke-width", QString::number((pen.getWidth()/100.0)).toStdString());
    //     } else {
    //        xmlWriter->addAttribute("stroke-width", QString::number(defaultElementWidth).toStdString());
    //    }
    //    xmlWriter->addAttribute("d", path);
    //    xmlWriter->closeElement();
    //}
    //else
    {
        //RS_DEBUG->print("RS_MakerCamSVG::writeLine: write standard line ");
        xmlWriter->addElement("line", NAMESPACE_URI_SVG);

        xmlWriter->addAttribute("x1", lengthXml(startpoint.x));
        xmlWriter->addAttribute("y1", lengthXml(startpoint.y));
        xmlWriter->addAttribute("x2", lengthXml(endpoint.x));
        xmlWriter->addAttribute("y2", lengthXml(endpoint.y));

        xmlWriter->closeElement();
    }
}

void LC_MakerCamSVG::writePolyline(RS_Polyline* polyline) {

    //RS_DEBUG->print("RS_MakerCamSVG::writePolyline: Writing polyline ...");

  AcGePoint3d pt;
  polyline->getStartPoint(pt);
  std::string path = svgPathMoveTo(convertToSvg(pt.asPoint2d()));

  NcGeCircArc2d ca2d;

  NcDbVoidPtrArray set;
  polyline->explode(set);


  for (int i = 0; i < set.length(); i++)
  {
    AcDbEntity* pEnt = AcDbEntity::cast((NcDbObject*)(set[i]));

    if (pEnt->isKindOf(RS_Arc::desc()))
      path += svgPathArc((RS_Arc*)pEnt);
    else
      if (pEnt->isKindOf(RS_Line::desc()))
        path += svgPathLineTo(convertToSvg(((RS_Line*)pEnt)->endPoint().asPoint2d()));
  }

    if (polyline->isClosed()) {

        path += svgPathClose();
    }

    xmlWriter->addElement("path", NAMESPACE_URI_SVG);

    xmlWriter->addAttribute("d", path);

    xmlWriter->closeElement();
}

void LC_MakerCamSVG::writeCircle(RS_Circle* circle) {

    //RS_DEBUG->print("RS_MakerCamSVG::writeCircle: Writing circle ...");

    RS_Vector center = convertToSvg(circle->center().asPoint2d());

    xmlWriter->addElement("circle", NAMESPACE_URI_SVG);

    xmlWriter->addAttribute("cx", lengthXml(center.x));
    xmlWriter->addAttribute("cy", lengthXml(center.y));
    xmlWriter->addAttribute("r", lengthXml(circle->radius()));

    xmlWriter->closeElement();
}

void LC_MakerCamSVG::writeArc(RS_Arc* arc) {

    //RS_DEBUG->print("RS_MakerCamSVG::writeArc: Writing arc ...");

  AcGePoint3d pt;
  arc->getStartPoint(pt);
  std::string path = svgPathMoveTo(convertToSvg(pt.asPoint2d())) +
                     svgPathArc(arc);

    xmlWriter->addElement("path", NAMESPACE_URI_SVG);

    xmlWriter->addAttribute("d", path);

    xmlWriter->closeElement();
}

void LC_MakerCamSVG::writeEllipse(RS_Ellipse* ellipse) {

  RS_Vector center = convertToSvg(ellipse->center().asPoint2d());
	const RS_Vector centerTranslation=center - ellipse->center().asPoint2d().asVector();

    double majorradius = ellipse->majorAxis().length();
    double minorradius = ellipse->minorAxis().lengthSqrd();

    if (convertEllipsesToBeziers) {

        std::string path = "";

        //if (ellipse->isEllipticArc()) 
        if (ellipse->isPeriodic())
        {

            const int segments = 4;

            //RS_DEBUG->print("RS_MakerCamSVG::writeEllipse: Writing ellipse arc approximated by 'path' with %d cubic bézier segments (as discussed in https://www.spaceroots.org/documents/ellipse/elliptical-arc.pdf) ...", segments);

            double x_axis_rotation = //2 * M_PI - ellipse->getAngle();
              ellipse->majorAxis().angleTo(AcGeVector3d::kXAxis);
                                      

            //double start_angle = 2 * M_PI - ellipse->getAngle2();
            //double end_angle = 2 * M_PI - ellipse->getAngle1();
            double start_angle = ellipse->startAngle();
            double end_angle = ellipse->endAngle();

            //if (ellipse->isReversed())
            //{
            //    double temp_angle = start_angle;
            //    start_angle = end_angle;
            //    end_angle = temp_angle;
            //}

            if (end_angle <= start_angle) {
                end_angle += 2 * M_PI;
            }

            double total_angle = end_angle - start_angle;

            double alpha = calcAlpha(total_angle / segments);

            RS_Vector start_point; //= centerTranslation + ellipse->getEllipsePoint(start_angle);
            {
              AcGePoint3d pt;
              ellipse->getStartPoint(pt);
              start_point = pt.asPoint2d();
            }

            path = svgPathMoveTo(start_point);

            for (int i = 1; i <= segments; i++) {
                double segment_start_angle = start_angle + ((i - 1) / (double)segments) * total_angle;
                double segment_end_angle = start_angle + (i / (double)segments) * total_angle;

				//RS_Vector segment_start_point = centerTranslation + ellipse->getEllipsePoint(segment_start_angle);
				//RS_Vector segment_end_point = centerTranslation + ellipse->getEllipsePoint(segment_end_angle);
                //RS_Vector segment_start_point = centerTranslation + ellipse->get   gment_start_angle);
                //RS_Vector segment_end_point = centerTranslation + ellipse->paramAtAngle(segment_end_angle);


                //RS_Vector segment_control_point_1 = segment_start_point + calcEllipsePointDerivative(majorradius, minorradius, x_axis_rotation, segment_start_angle) * alpha;
                //RS_Vector segment_control_point_2 = segment_end_point - calcEllipsePointDerivative(majorradius, minorradius, x_axis_rotation, segment_end_angle) * alpha;

                //path += svgPathCurveTo(segment_end_point, segment_control_point_1, segment_control_point_2);
            }
        }
        else {

            //RS_DEBUG->print("RS_MakerCamSVG::writeEllipse: Writing ellipse approximated by 'path' with 4 cubic bézier segments (as discussed in http://www.tinaja.com/glib/ellipse4.pdf) ...");

            const double kappa = 0.551784;

            RS_Vector major {majorradius, 0.0};
            RS_Vector minor {0.0, minorradius};

            RS_Vector flip_y {1.0, -1.0};

            //major.rotate(ellipse->getAngle());
            //minor.rotate(ellipse->getAngle());

            //major.scale(flip_y);
            //minor.scale(flip_y);

            RS_Vector offsetmajor {major * kappa};
            RS_Vector offsetminor {minor * kappa};

            //path = svgPathMoveTo(center - major) +
            //       svgPathCurveTo((center - minor), (center - major - offsetminor), (center - minor - offsetmajor)) +
            //       svgPathCurveTo((center + major), (center - minor + offsetmajor), (center + major - offsetminor)) +
            //       svgPathCurveTo((center + minor), (center + major + offsetminor), (center + minor + offsetmajor)) +
            //       svgPathCurveTo((center - major), (center + minor - offsetmajor), (center - major + offsetminor)) +
            //       svgPathClose();
        }

        xmlWriter->addElement("path", NAMESPACE_URI_SVG);

        xmlWriter->addAttribute("d", path);

        xmlWriter->closeElement();
    }
    else {

    //    if (ellipse->isEllipticArc()) {

    //        //RS_DEBUG->print("RS_MakerCamSVG::writeEllipse: Writing ellipse arc as 'path' with arc segments ...");

    //        double x_axis_rotation = 180 - (RS_Math::rad2deg(ellipse->getAngle()));

    //        double startangle = RS_Math::rad2deg(ellipse->getAngle1());
    //        double endangle = RS_Math::rad2deg(ellipse->getAngle2());

    //        if (endangle <= startangle) {
    //            endangle += 360;
    //        }

    //        bool large_arc_flag = ((endangle - startangle) > 180);
    //        bool sweep_flag = false;

    //        if (ellipse->isReversed()) {
    //            large_arc_flag = !large_arc_flag;
    //            sweep_flag = !sweep_flag;
    //        }

    //        std::string path = svgPathMoveTo(convertToSvg(ellipse->getStartpoint())) +
    //                           svgPathArc(convertToSvg(ellipse->getEndpoint()), majorradius, minorradius, x_axis_rotation, large_arc_flag, sweep_flag);

    //        xmlWriter->addElement("path", NAMESPACE_URI_SVG);

    //        xmlWriter->addAttribute("d", path);

    //        xmlWriter->closeElement();
    //    }
    //    else {

    //        //RS_DEBUG->print("RS_MakerCamSVG::writeEllipse: Writing full ellipse as 'ellipse' ...");

    //        double angle = 180 - (RS_Math::rad2deg(ellipse->getAngle()) - 90);

    //        std::string transform = "translate(" + lengthXml(center.x) + ", " + lengthXml(center.y) + ") " +
    //                                "rotate(" + numXml(angle) + ")";

    //        xmlWriter->addElement("ellipse", NAMESPACE_URI_SVG);

    //        xmlWriter->addAttribute("rx", lengthXml(minorradius));
    //        xmlWriter->addAttribute("ry", lengthXml(majorradius));
    //        xmlWriter->addAttribute("transform", transform);

    //        xmlWriter->closeElement();
    //    }
    }
}

// NOTE: Quite obviously, the spline implementation in LibreCAD is a bit shaky.
//       It looks as if degree 1 to 3 splines are hold in the RS_Spline object
//       (if created using the control point method vs. the pass through point
//       method). However after saving degree 2 splines and reopening the file,
//       these splines are hold in the "artificial" LC_SplinePoints object.
void LC_MakerCamSVG::writeSpline(RS_Spline* spline) {

    //if (spline->degree() == 2) {
    //    //RS_DEBUG->print("RS_MakerCamSVG::writeSpline: Writing piecewise quadratic spline as 'path' with quadratic bézier segments");

    //    writeQuadraticBeziers(spline->getControlPoints(), spline->isClosed());
    //}
    //else if (spline->degree() == 3) {
    //    //RS_DEBUG->print("RS_MakerCamSVG::writeSpline: Writing piecewise cubic spline as 'path' with cubic bézier segments");

    //    writeCubicBeziers(spline->getControlPoints(), spline->isClosed());
    //}
    //else {
    //    //RS_DEBUG->print(RS_Debug::D_NOTICE,
    //    //                "RS_MakerCamSVG::writePiecewiseCubicSpline: Splines with degree '%d' not implemented",
    //    //                (int)spline->getDegree());
    //}
}

//void LC_MakerCamSVG::writeSplinepoints(LC_SplinePoints* splinepoints) {
//
//    //RS_DEBUG->print("RS_MakerCamSVG::writeSplinepoints: Writing piecewise quadratic spline as 'path' with quadratic bézier segments");
//
//    writeQuadraticBeziers(splinepoints->getControlPoints(), splinepoints->isClosed());
//}

void LC_MakerCamSVG::writeCubicBeziers(const std::vector<RS_Vector> &control_points, bool is_closed) {

    std::vector<RS_Vector> bezier_points = calcCubicBezierPoints(control_points, is_closed);

    std::string path = svgPathMoveTo(convertToSvg(bezier_points[0]));

    int bezier_points_size = bezier_points.size();

    int bezier_count = ((bezier_points_size - 1) / 3);

    for (int i = 0; i < bezier_count; i++) {
        path += svgPathCurveTo(convertToSvg(bezier_points[3 * (i + 1)]), convertToSvg(bezier_points[3 * (i + 1) - 2]), convertToSvg(bezier_points[3 * (i + 1) - 1]));
    }

    xmlWriter->addElement("path", NAMESPACE_URI_SVG);

    xmlWriter->addAttribute("d", path);

    xmlWriter->closeElement();
}

void LC_MakerCamSVG::writeQuadraticBeziers(const std::vector<RS_Vector> &control_points, bool is_closed) {

    std::vector<RS_Vector> bezier_points = calcQuadraticBezierPoints(control_points, is_closed);

    std::string path = svgPathMoveTo(convertToSvg(bezier_points[0]));

    int bezier_points_size = bezier_points.size();

    int bezier_count = ((bezier_points_size - 1) / 2);

    for (int i = 0; i < bezier_count; i++) {
        path += svgPathQuadraticCurveTo(convertToSvg(bezier_points[2 * (i + 1)]), convertToSvg(bezier_points[2 * (i + 1) - 1]));
    }

    xmlWriter->addElement("path", NAMESPACE_URI_SVG);

    xmlWriter->addAttribute("d", path);

    xmlWriter->closeElement();
}

std::vector<RS_Vector> LC_MakerCamSVG::calcCubicBezierPoints(const std::vector<RS_Vector> &control_points, bool is_closed) {

    std::vector<RS_Vector> bezier_points;

    int control_points_size = control_points.size();

    int bezier_points_size;

    if (is_closed) {

      int i;
        for (i = 0; i < (control_points_size - 1); i++) {
            bezier_points.push_back(control_points[i]);

            bezier_points.push_back((control_points[i] * 2.0 + control_points[i + 1].asVector()) / 3.0);
            bezier_points.push_back((control_points[i] + control_points[i + 1].asVector() * 2.0) / 3.0);
        }

        bezier_points.push_back(control_points[control_points_size - 1]);
        bezier_points.push_back((control_points[control_points_size - 1] * 2.0 + control_points[0].asVector()) / 3.0);
        bezier_points.push_back((control_points[control_points_size - 1] + control_points[0].asVector() * 2.0) / 3.0);
        bezier_points.push_back(control_points[0]);

        // Auxiliary points for easier calculation
        bezier_points.insert(bezier_points.begin(), ((control_points[control_points_size - 1] + control_points[0].asVector() * 2.0) / 3.0));
        bezier_points.push_back((control_points[0] * 2.0 + control_points[1].asVector()) / 3.0);

        bezier_points_size = bezier_points.size();

        for (i = 1; i < (bezier_points_size - 1); i += 3) {
            bezier_points[i] = ((bezier_points[i - 1] + bezier_points[i + 1].asVector()) / 2.0);
        }

        // Remove auxiliary points
        bezier_points.pop_back();
        bezier_points.erase(bezier_points.begin());
    }
    else {
        // Extend control point list with interpolation points that act as control
        // points for the bezier curves
        for (int i = 0; i < (control_points_size - 1); i++) {
            bezier_points.push_back(control_points[i]);

            bool more_than_bezier = (control_points_size > 4);

            if (more_than_bezier) {

                bool first_or_last = ((i == 0) || (i == (control_points_size - 2)));

                if (!first_or_last) {

                    bool second_or_second_last = ((i == 1) || (i == (control_points_size - 3)));

                    if (second_or_second_last) {
                        bezier_points.push_back((control_points[i] + control_points[i + 1].asVector()) / 2.0);
                    }
                    else {
                        bezier_points.push_back((control_points[i] * 2.0 + control_points[i + 1].asVector()) / 3.0);
                        bezier_points.push_back((control_points[i] + control_points[i + 1].asVector() * 2.0) / 3.0);
                    }
                }
            }
        }

        bezier_points.push_back(control_points[control_points_size - 1]);

        bezier_points_size = bezier_points.size();

        // Update the up to now original spline control points to bezier endpoints
        for (int i = 3; i < (bezier_points_size - 1); i += 3) {
            bezier_points[i] = ((bezier_points[i - 1] + bezier_points[i + 1].asVector()) / 2.0);
        }
    }

    return bezier_points;
}

std::vector<RS_Vector> LC_MakerCamSVG::calcQuadraticBezierPoints(const std::vector<RS_Vector> &control_points, bool is_closed) {

    std::vector<RS_Vector> bezier_points;

    int control_points_size = control_points.size();

    if (is_closed) {
        for (int i = 0; i < (control_points_size - 1); i++) {
            bezier_points.push_back(control_points[i]);

            bezier_points.push_back((control_points[i] + control_points[i + 1].asVector()) / 2.0);
        }

        bezier_points.push_back(control_points[control_points_size - 1]);
        bezier_points.push_back((control_points[control_points_size - 1] + control_points[0].asVector()) / 2.0);
        bezier_points.push_back(control_points[0]);
        bezier_points.push_back((control_points[0] + control_points[1].asVector()) / 2.0);

        // Remove superfluous first point
        bezier_points.erase(bezier_points.begin());
    }
    else {
        for (int i = 0; i < (control_points_size - 1); i++) {
            bezier_points.push_back(control_points[i]);

            bool first_or_last = ((i == 0) || (i == (control_points_size - 2)));

            if (!first_or_last) {
                bezier_points.push_back((control_points[i] + control_points[i + 1].asVector()) / 2.0);
            }
        }

        bezier_points.push_back(control_points[control_points_size - 1]);
    }

    return bezier_points;
}

string doubleToString(double value, int precision)
{
  std::string ret = std::to_string(value);
  //ret.setNum(value, 'f', precision);
  int f = ret.find('.');
  if (f > 0) {
    // remove trailing zeros:
    while (ret.at(ret.length() - 1) == '0') {
      ret.resize(ret.length() - 1);
    }
    // remove trailing .
    if (ret.at(ret.length() - 1) == '.') {
      ret.resize(ret.length() - 1);
    }
  }
  return ret;

  //std::string rounded = std::to_string(
  //  std::round(value * std::pow(10, precision)) /
  //  std::pow(10, precision)).substr(0, std::to_string(
  //      std::round(value * std::pow(10, precision)) /
  //      std::pow(10, precision)).find(".") + precision + 1);
  //return rounded;

}

std::string LC_MakerCamSVG::numXml(double value) {

    return doubleToString(value, 8);
}

std::string LC_MakerCamSVG::lengthXml(double value) const
{
    return numXml(lengthFactor*value);
}

RS_Vector LC_MakerCamSVG::convertToSvg(RS_Vector vector) const
{

    RS_Vector translated((vector.x - min.x), (max.y - vector.y));

    return translated + offset.asVector();
}

std::string LC_MakerCamSVG::svgPathClose() const
{
  return "Z ";
}

std::string LC_MakerCamSVG::svgPathCurveTo(RS_Vector point, RS_Vector controlpoint1, RS_Vector controlpoint2) const
{
    return "C" + lengthXml(controlpoint1.x) + "," + lengthXml(controlpoint1.y) + " " +
           lengthXml(controlpoint2.x) + "," + lengthXml(controlpoint2.y) + " " +
           lengthXml(point.x) + "," + lengthXml(point.y) + " ";
}

std::string LC_MakerCamSVG::svgPathQuadraticCurveTo(RS_Vector point, RS_Vector controlpoint) const
{
    return "Q" + lengthXml(controlpoint.x) + "," + lengthXml(controlpoint.y) + " " +
           lengthXml(point.x) + "," + lengthXml(point.y) + " ";
}

std::string LC_MakerCamSVG::svgPathLineTo(RS_Vector point) const
{
    return "L" + lengthXml(point.x) + "," + lengthXml(point.y) + " ";
}

std::string LC_MakerCamSVG::svgPathMoveTo(RS_Vector point) const
{
    return "M" + lengthXml(point.x) + "," + lengthXml(point.y) + " ";
}

std::string LC_MakerCamSVG::svgPathArc(RS_Arc* arc) const
{
  AcGePoint3d pt;
  arc->getEndPoint(pt);
    RS_Vector endpoint = convertToSvg(pt.asPoint2d());
    double radius = arc->radius();

    //double startangle = RS_Math::rad2deg(arc->getAngle1());
    //double endangle = RS_Math::rad2deg(arc->getAngle2());
    double startangle = RS_Math::rad2deg(arc->startAngle());
    double endangle = RS_Math::rad2deg(arc->endAngle());

    if (endangle <= startangle) {
        endangle += 360;
    }

    bool large_arc_flag = ((endangle - startangle) > 180);
    bool sweep_flag = false;

    //if (arc->isReversed())
    {
        large_arc_flag = !large_arc_flag;
        sweep_flag = !sweep_flag;
    }

    return svgPathArc(endpoint, radius, radius, 0.0, large_arc_flag, sweep_flag);
  return "";
}

std::string LC_MakerCamSVG::svgPathArc(RS_Vector point, double radius_x, double radius_y, double x_axis_rotation, bool large_arc_flag, bool sweep_flag) const
{
    return "A" + lengthXml(radius_x) + "," + lengthXml(radius_y) + " " +
           numXml(x_axis_rotation) + " " +
           (large_arc_flag ? "1" : "0") + "," +
           (sweep_flag ? "1" : "0") + " " +
           lengthXml(point.x) + "," + lengthXml(point.y) + " ";
}

RS_Vector LC_MakerCamSVG::calcEllipsePointDerivative(double majorradius, double minorradius, double x_axis_rotation, double angle) const
{
    RS_Vector vector((-majorradius * cos(x_axis_rotation) * sin(angle)) - (minorradius * sin(x_axis_rotation) * cos(angle)),
                     (-majorradius * sin(x_axis_rotation) * sin(angle)) + (minorradius * cos(x_axis_rotation) * cos(angle)));

    return vector;
}

double LC_MakerCamSVG::calcAlpha(double angle) {

    return sin(angle) * ((sqrt(4.0 + 3.0 * pow(tan(angle / 2), 2.0)) - 1.0) / 3.0);
}

void LC_MakerCamSVG::writeImage(RS_Image* image)
{
    //RS_DEBUG->print("RS_MakerCamSVG::writeImage: Writing image ...");
    //if (exportImages){
    //    RS_Vector insertionPoint = convertToSvg(image->getInsertionPoint());

    //    xmlWriter->addElement("image", NAMESPACE_URI_SVG);
    //    xmlWriter->addAttribute("x", lengthXml(insertionPoint.x));
    //    xmlWriter->addAttribute("y", lengthXml(insertionPoint.y - image->getImageHeight()));
    //    xmlWriter->addAttribute("height", lengthXml(image->getImageHeight()));
    //    xmlWriter->addAttribute("width", lengthXml(image->getImageWidth()));
    //    xmlWriter->addAttribute("preserveAspectRatio", "none");  //height and width above used
    //    xmlWriter->addAttribute("href", image->getData().file.toStdString(), NAMESPACE_URI_XLINK);
    //    xmlWriter->closeElement();
    //}
}


std::string LC_MakerCamSVG::svgPathAnyLineType(RS_Vector startpoint, RS_Vector endpoint, RS2::LineType type) const
{
    //RS_DEBUG->print("RS_MakerCamSVG::svgPathUniLineType: convert line to dot/dash path");

    const int dotFactor     = 1;    // ..........
    const int dashFactor    = 3;    // -- -- -- --
    const int dashDotFactor = 4;    // --. --. --.
    const int divideFactor  = 5;    // --.. --.. --.. --..
    const int centerFactor  = 5;    // -- - -- - -- -
    const int borderFactor  = 7;    // -- -- . -- -- . -- -- .

    const double lineScaleTiny  = 0.25;
    const double lineScale2     = 0.5;
    const double lineScaleOne   = 1.0;
    const double lineScaleX2    = 2.0;

    std::string path;
    double lineScale;
    double lineFactor;

    double lineLengh = startpoint. distanceTo(endpoint);
    switch(type){

    case RS2::DotLineTiny:{ lineScale = lineScaleTiny; lineFactor = dotFactor; break;}
    case RS2::DotLine2:{ lineScale = lineScale2; lineFactor = dotFactor; break;}
    case RS2::DotLine:{ lineScale = lineScaleOne;  lineFactor = dotFactor; break;}
    case RS2::DotLineX2:{ lineScale = lineScaleX2; lineFactor = dotFactor; break;}

    case RS2::DashLineTiny:{ lineScale = lineScaleTiny; lineFactor = dashFactor; break;}
    case RS2::DashLine2:{ lineScale = lineScale2; lineFactor = dashFactor; break;}
    case RS2::DashLine:{ lineScale = lineScaleOne;  lineFactor = dashFactor; break;}
    case RS2::DashLineX2:{ lineScale = lineScaleX2; lineFactor = dashFactor; break;}

    case RS2::DashDotLineTiny:{ lineScale = lineScaleTiny; lineFactor = dashDotFactor; break;}
    case RS2::DashDotLine2:{ lineScale = lineScale2; lineFactor = dashDotFactor; break;}
    case RS2::DashDotLine:{ lineScale = lineScaleOne;  lineFactor = dashDotFactor; break;}
    case RS2::DashDotLineX2:{ lineScale = lineScaleX2; lineFactor = dashDotFactor; break;}

    case RS2::DivideLineTiny:{ lineScale = lineScaleTiny; lineFactor = divideFactor; break;}
    case RS2::DivideLine2:{ lineScale = lineScale2; lineFactor = divideFactor; break;}
    case RS2::DivideLine:{ lineScale = lineScaleOne;  lineFactor = divideFactor; break;}
    case RS2::DivideLineX2:{ lineScale = lineScaleX2; lineFactor = divideFactor; break;}

    case RS2::CenterLineTiny:{ lineScale = lineScaleTiny; lineFactor = centerFactor; break;}
    case RS2::CenterLine2:{ lineScale = lineScale2; lineFactor = centerFactor; break;}
    case RS2::CenterLine:{ lineScale = lineScaleOne;  lineFactor = centerFactor; break;}
    case RS2::CenterLineX2:{ lineScale = lineScaleX2; lineFactor = centerFactor; break;}

    case RS2::BorderLineTiny:{ lineScale = lineScaleTiny; lineFactor = borderFactor; break;}
    case RS2::BorderLine2:{ lineScale = lineScale2; lineFactor = borderFactor; break;}
    case RS2::BorderLine:{ lineScale = lineScaleOne;  lineFactor = borderFactor; break;}
    case RS2::BorderLineX2:{ lineScale = lineScaleX2; lineFactor = borderFactor; break;}
    default: { lineScale = lineScaleOne; lineFactor = dotFactor; break;}
    }

    //doesn't make an sense to have pattern longer than a line
    double dashLinePatternLength = defaultDashLinePatternLength;

    if (lineLengh < (dashLinePatternLength*lineFactor*lineScale)) {
        dashLinePatternLength = lineLengh/(lineFactor*lineScale);
        //RS_DEBUG->print(RS_Debug::D_WARNING, "Line length shorter than a line pattern, updated length is %f mm", dashLinePatternLength);
    }

    double lineStep = lineScale*dashLinePatternLength*lineFactor;
    int numOfIter = round(lineLengh/lineStep);

    RS_Vector step((endpoint.x-startpoint.x)/numOfIter,(endpoint.y-startpoint.y)/numOfIter);
    RS_Vector lastPos(startpoint.x, startpoint.y);

    for (int i=0; i< numOfIter; i++){
        path += getLinePattern(&lastPos, step, type, (1.0/lineFactor) );
    }

    return path;
}

std::string LC_MakerCamSVG::getLinePattern(RS_Vector *lastPos, RS_Vector step, RS2::LineType type, double lineScale) const
{
    std::string path;

    switch(type){
    case RS2::DotLineTiny:
    case RS2::DotLine2:
    case RS2::DotLine:
    case RS2::DotLineX2:{
        path += getPointSegment(lastPos, step, lineScale);
        break;
    }

    case RS2::DashLineTiny:
    case RS2::DashLine2:
    case RS2::DashLine:
    case RS2::DashLineX2:{
        path += getLineSegment(lastPos, step, lineScale, true);
        break;
    }

    case RS2::DashDotLineTiny:
    case RS2::DashDotLine2:
    case RS2::DashDotLine:
    case RS2::DashDotLineX2:{
        path += getLineSegment(lastPos, step, lineScale, true);
        path += getPointSegment(lastPos, step, lineScale);
        break;
    }

    case RS2::DivideLineTiny:
    case RS2::DivideLine2:
    case RS2::DivideLine:
    case RS2::DivideLineX2: {
        path += getLineSegment(lastPos, step, lineScale, true);
        path += getPointSegment(lastPos, step, lineScale);
        path += getPointSegment(lastPos, step, lineScale);
        break;
    }

    case RS2::CenterLineTiny:
    case RS2::CenterLine2:
    case RS2::CenterLine:
    case RS2::CenterLineX2:{
        path += getLineSegment(lastPos, step, lineScale, true);
        path += getLineSegment(lastPos, step, lineScale, false);
        break;
    }

    case RS2::BorderLineTiny:
    case RS2::BorderLine2:
    case RS2::BorderLine:
    case RS2::BorderLineX2:{
        path += getLineSegment(lastPos, step, lineScale, true);
        path += getLineSegment(lastPos, step, lineScale, true);
        path += getPointSegment(lastPos, step, lineScale);
        break;
    }

    default:{
        //RS_DEBUG->print(RS_Debug::D_WARNING,"RS_MakerCamSVG::getLinePattern: unsupported line type %d\n", type);
        path += svgPathMoveTo(convertToSvg(*lastPos));
        *lastPos += step.asVector() *lineScale;
        path += svgPathLineTo(convertToSvg(*lastPos));
        break;
    }
    }
    return path;
}

std::string LC_MakerCamSVG::getPointSegment(RS_Vector *lastPos, RS_Vector step, double lineScale) const
{
    std::string path;
    //0.2 - is a diametr of point on early implementation of MakerCAM.
    //! \todo need to add a option to control this value from export dialog and test on laser engraver
    const double dotSize = 0.2;
    double scaleTo;

    if (fabs(step.x) >= fabs(step.y)){
        scaleTo = dotSize/fabs(step.x);
    } else {
        scaleTo = dotSize/fabs(step.y);
    }
    path += svgPathMoveTo(*lastPos);
    path += svgPathLineTo(*lastPos+step.asVector() *scaleTo);
    *lastPos += step.asVector() *lineScale;
    return path;
}

std::string LC_MakerCamSVG::getLineSegment(RS_Vector *lastPos, RS_Vector step, double lineScale, bool x2)const
{
    std::string path;
    path += svgPathMoveTo(*lastPos);
    if (x2)
        *lastPos += (step.asVector() *lineScale*2);
    else
        *lastPos += (step.asVector() *lineScale);
    path += svgPathLineTo(*lastPos);
    *lastPos += step.asVector() *lineScale;
    return path;
}
