/****************************************************************************
**
** This file is part of the LibreCAD project, a 2D CAD program
**
** Copyright (C) 2015 Christian Luginbühl (dinkel@pimprecords.com)
**
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License along
** with this program; if not, write to the Free Software Foundation, Inc.,
** 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
**
**********************************************************************/

#ifndef RS_XMLWRITERQXMLSTREAMWRITER_H
#define RS_XMLWRITERQXMLSTREAMWRITER_H

#include <memory>
#include "lc_xmlwriterinterface.h"

//class QXmlStreamWriter;
class CXmlDocumentWrapper;

class LC_XMLWriterQXmlStreamWriter : public LC_XMLWriterInterface {
public:
	LC_XMLWriterQXmlStreamWriter();

    ~LC_XMLWriterQXmlStreamWriter() override;

    void createRootElement(const std::string &name, const std::string &namespace_uri = "") override;

    void addElement(const std::string &name, const std::string &namespace_uri = "") override;

    void addAttribute(const std::string &name, const std::string &value, const std::string &namespace_uri = "") override;

    void addNamespaceDeclaration(const std::string &prefix, const std::string &namespace_uri) override;

    void closeElement() override;

    std::string documentAsString() override;

private:

	//std::unique_ptr<QXmlStreamWriter> xmlWriter;
  std::unique_ptr<CXmlDocumentWrapper> xmlWriter;
};

#endif
