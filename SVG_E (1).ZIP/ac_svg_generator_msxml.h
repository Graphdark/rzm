#pragma once
class ac_svg_generator_msxml
{
};

